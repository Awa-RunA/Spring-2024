package android.bignerdranch.finalprojectv4;

import java.util.List;

public class Recipe {
    private String title;
    private int imageResource;
    private List<String> ingredients;
    private String instructions;

    public Recipe(String title, int imageResource, List<String> ingredients, String instructions) {
        this.title = title;
        this.imageResource = imageResource;
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    public String getTitle() {
        return title;
    }

    public int getImageResource() {
        return imageResource;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public String getInstructions() {
        return instructions;
    }
}

