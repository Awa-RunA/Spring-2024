package android.bignerdranch.finalprojectv4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class RecipeDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_item);

        // Get the recipe data from the intent
        Recipe recipe = getIntent().getParcelableExtra("recipe");
    }
}
