package android.bignerdranch.finalprojectv4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecipeAdapter adapter;
    private TextView recipeTitleTextView ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recipeRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Recipe> recipes = generateRecipes();
        RecyclerView recyclerView = findViewById(R.id.recipeRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecipeAdapter adapter = new RecipeAdapter(recipes);
        recyclerView.setAdapter(adapter);


        Button buttonGoToRecipe = findViewById(R.id.buttonGoToRecipe);
        buttonGoToRecipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToRecipePage();
            }
        });



    }
    private void goToRecipePage() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.Account) {
            // Handle Account menu item click
            return true;
        }
        else if (id==R.id.SavedRecipes){

            return true;
        }
        else if (id==R.id.PantryList){

            return true;
        }
        else if (id==R.id.RecipeMonth){

            return true;
        }else if (id==R.id.Settings){

            return true;
        }
        else if (id==R.id.Settings){

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private List<Recipe> generateRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe("Breakfast Burrito", R.drawable.breakfast_burritos_souplovingnicole_2000_0a26bef5913f495f96c5a4672ad50f95, Arrays.asList("6 Pieces of Bacon ", " 2 Eggs", "Cheddar Cheese","1 Flour Tortilla"), "Place bacon in large, deep skillet. Cook over medium-high heat until evenly brown. Drain, and set aside. Wrap tortillas in foil and warm them in the oven. Fry eggs in a greased skillet until firm. Top tortillas with strips of bacon, eggs, and little cheese. Roll tortillas into burritos and serve."));
        recipes.add(new Recipe("Test Food",R.drawable.article_291139_the_top_10_healthiest_foods_for_kids__02_4b745e57928c4786a61b47d8ba920058, Arrays.asList("1 Egg","Handfull of Spinach", "Seasoning"),"Cook egg on stove and add spinach while scrabbling. Add seasoning at the end."));
        return recipes;
    }
    public void goToRecipePage(View view) {

        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }


}
